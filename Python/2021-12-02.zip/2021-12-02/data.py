all_users = [
    {"username": "gal", "password": 'gal123', "isLogin": False, "points": 0},
    {"username": "dani", "password": 'dani123', "isLogin": False, "points": 0},
    {"username": "ben", "password": 'ben123', "isLogin": True, "points": 0},
    {"username": "tal", "password": 'tal123', "isLogin": True, "points": 0},
]



