print("into work_with_import_and_module_2.py ")



def plus():
    num1 = int(input('Enter num1'))
    num2 = int(input('Enter num2'))
    print( num1 + num2 )
    return num1 + num2