print("into string.py")

print(type("hola"))

text1 = 'כל הכבוד לצה"ל'
print(text1)

text2 = "ג'ון סטודנט מצטיין"
print(text2)

text3 = "hola \n class \nfrom \n python"
print(text3)


text4 = """
"Lorem ipsum doc'  dolor sit amet, consectetur adipiscing elit, 
sed do eiusmod tempor incididunt ut labore et 
dolore magna aliqua. Ut enim ad minim veniam, 
quis nostrud exercitation ullamco laboris nisi ut 
aliquip ex ea commodo consequat"
"""
print(text4)

text5 = '''
"Lorem ipsum doc'  dolor sit amet, consectetur adipiscing elit, 
sed do eiusmod tempor incididunt ut labore et 
dolore magna aliqua. Ut enim ad minim veniam, 
quis nostrud exercitation ullamco laboris nisi ut 
aliquip ex ea commodo consequat"
'''
print(text5)

text6 = "Gal Lavi"
print(len(text6))  # 8
print(text6[1])  # a

for i in text6:
    print(i)

text7 = "Hola from Gal Lavi and from Python"

print("Gal" in text7)  # True
print("gal" in text7)  # False

print("dani" in text7)  # False
print("dani" not in text7)  # True


text8 = "Hola from Gal Lavi and from Python"
x = text8.upper()
print(x)
print(text8)

y = text8.lower()
print(y)
print(text8)


text9 = text8 + " and form Hackeru"  # string + string
print(text9)

num = 10
# ERROR print( "Total is" + num )  # can NOT string + number
print("Total is " + str(num))



print("************ text.formt() ************** ")

num1 = 2
num2 = 9.80

text10 = "for {} Product the price is {} "
x = text10.format(3, 15)  # must to insert 2 value !!

print(x) # for 3 Product the price is 15
print(text10)  # "for {} Product the price is {} "

y = text10.format(10, "text")
print(y)  # for 10 Product the price is text
print(text10)

z = text10.format(num1, num2)
print(z)  # for 2 Product the price is 9.8
print(text10)