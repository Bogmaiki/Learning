import data
users = data.all_users
print(users)


def login(username, password):
    print("into func login")
    for user in users:
        # print(user)
        if user["username"] == username and user["password"] == password:
            user["isLogin"] = True
            return user
    return False



u_name = input('Enter username')  # 'gal'
u_pass = input('Enter Password')  # 'gal123'

userLogin = login('gal', 'gal123')
print(userLogin)

userLogin['points'] = 100
print(userLogin)




