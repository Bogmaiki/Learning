print("into work_with_import_and_module_1.py ")

x = 10

def say_hola():
    name = input('Enter name')
    print('Hola ' + name )